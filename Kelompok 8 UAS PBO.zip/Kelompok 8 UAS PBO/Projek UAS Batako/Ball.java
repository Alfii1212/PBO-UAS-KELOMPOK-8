import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Kelompok 8
 * Alfi Sukmanata - 2211102441168
 * Debby Fahrizal Rahman - 2211102441196
 * Muhammad Afif Aunur Rohman - 2211102441185
 */
public class Ball extends Actor
{

    /**
     * changeInX and ChangeInY are the movement in the X and Y directions for the ball.
     * If changeInX is positive, the ball will travel right, if negative the ball will travel left.
     * If changeInY is positive, the ball will travel down, if negative the ball will travel up.
     */
    private int changeInX; //Variabel yang menyimpan perubahan posisi (kecepatan) bola pada sumbu X.
    private int changeInY; //Variabel yang menyimpan perubahan posisi (kecepatan) bola pada sumbu Y.
    private int healthCount; //Variabel yang menyimpan jumlah nyawa atau health.
    private boolean stuck = true; //Variabel yang menunjukkan apakah bola stuck pada paddle atau tidak.
    private int count = 2; //ariabel penghitung untuk membuat asap (smoke) setiap beberapa iterasi.
    private GreenfootSound sound = new GreenfootSound("proton.mp3"); //Objek suara untuk efek suara saat bola memantul.
    /**
     * Act. Bergerak jika tidak mengalami stuck.
     */
    public void act() //Metode yang dipanggil setiap kali tombol "Act" atau "Run" ditekan dalam lingkungan permainan.
    {
        if (!stuck) 
        {
            move();
            makeSmoke();
            checkOut();
            //Jika bola tidak terikat pada paddle, maka panggil metode move(), makeSmoke(), dan checkOut().
        }
    }

    /**
     * Pindahkan bola. Kemudian memeriksa apakah bola terkena hit.
     */
    public void move() //Metode untuk memindahkan posisi bola dan memeriksa interaksi dengan objek lain.
    {
        /** setLocation memindahkan posisi bola, dengan menempatkannya
         * pada posisi lamanya.
         */
        setLocation (getX() + changeInX, getY() + changeInY); //Memindahkan posisi bola berdasarkan perubahan kecepatan pada sumbu X dan Y.
        checkPaddle(); //Memeriksa interaksi dengan paddle.
        checkWalls(); //Memeriksa jika bola bertabrakan dengan dinding.
        checkBlock(); //Memeriksa interaksi dengan blok.
    }

    /**
     * Memeriksa apakah bola menyentuh paddle, lalu menyesuaikan pergerakannya.
     */
    private void checkPaddle() //Metode untuk memeriksa apakah bola bersentuhan dengan paddle.
    {
        Actor paddle = getOneIntersectingObject(Paddle.class); //Mendapatkan objek paddle yang bersentuhan dengan bola.
        if (paddle != null) {
            //ika terdapat paddle:
            //Membalikkan pergerakan bola pada sumbu Y (changeInY = -changeInY;).
            //Menghitung offset dan mempengaruhi pergerakan pada sumbu X berdasarkan posisi bola terhadap paddle.
            changeInY = -changeInY;
            int offset = getX() - paddle.getX();
            changeInX = changeInX + (offset/7);
            if (changeInX > 9) {
                changeInX = 9;
            }
            if (changeInX < -9) {
                changeInX = -9;
            }
        }            
    }

    /**
     * Memeriksa apakah kita telah menabrak salah satu dari tiga dinding. Membalikkan arah.
     */
    private void checkWalls() //Metode untuk memeriksa jika bola bersentuhan dengan dinding dunia permainan.
    {
        if (getX() == 0 || getX() == getWorld().getWidth()-1) {
            changeInX = -changeInX; //Jika bola mencapai batas kiri atau kanan dunia, maka membalikkan pergerakan pada sumbu X (changeInX = -changeInX;).
        }
        if (getY() == 0) {
            changeInY = -changeInY; //Jika bola mencapai batas atas dunia, maka membalikkan pergerakan pada sumbu Y (changeInY = -changeInY;).
        }
    }

    /**
     * Memeriksa apakah kita diluar (Layar bagian bawah)
     */
    private void checkOut() //Metode untuk memeriksa jika bola berada di bagian bawah dunia permainan.
    {
        if (getY() == getWorld().getHeight()-1) { //ika bola mencapai bagian bawah dunia:
            Greenfoot.playSound("lost_life.mp3"); //Memainkan suara kehilangan nyawa ("lost_life.mp3").
            ((Board) getWorld()).ballOut(); //Memanggil metode ballOut() dari kelas Board untuk mengurangi nyawa dan mengupdate jumlah hati di layar.

            healthCount = ((Board) getWorld()).getHeart();
            this.getWorld().removeObjects(getWorld().getObjects(Health.class));
            //ika jumlah nyawa masih tersisa, menambahkan kembali hati di layar.
            if(healthCount == 3){
                Health health2 = new Health();
                getWorld().addObject(health2,740, 20);
                Health health3 = new Health();
                getWorld().addObject(health3,764,20); 
                healthCount -= 1;
                ((Board) getWorld()).setHeart(healthCount);
                getWorld().removeObject(this);
            }
            else if (healthCount == 2){

                Health health3 = new Health();
                getWorld().addObject(health3,764,20); 
                healthCount -= 1;
                ((Board) getWorld()).setHeart(healthCount);
                getWorld().removeObject(this);
            }
            else if (healthCount == 1){
                this.getWorld().removeObjects(getWorld().getObjects(Block.class));
                ((Board) getWorld()).gameOver();
                //Jika jumlah nyawa habis, memanggil metode gameOver() dari kelas Board.

            }
        }
    }

    private void makeSmoke() //Metode untuk membuat efek asap (smoke) setiap beberapa iterasi.
    {
        count--; //Mengurangi hitungan setiap iterasi.
        if (count == 0) {
            getWorld().addObject ( new Smoke(), getX(), getY());
            count = 2; //Jika hitungan mencapai 0, maka membuat objek Smoke dan mengatur ulang hitungan.
        }
    }

    /**
     * Memerikasa jika bola menabrak salah satu blocks. Balikkan arah jika perlu.
     */
    private void checkBlock() //Metode untuk memeriksa jika bola bersentuhan dengan blok.
    {
        if( !(getWorld().getObjects(Block.class).size() == 0  )){
            Actor block = getOneIntersectingObject(Block.class);
            //Mendapatkan objek blok yang bersentuhan dengan bola.
            if (block != null) { //Jika terdapat blok:
                changeInY = -changeInY; //Membalikkan pergerakan bola pada sumbu Y (changeInY = -changeInY;).
                int offset = getX() - block.getX(); //Menghitung offset dan mempengaruhi pergerakan pada sumbu X berdasarkan posisi bola terhadap blok.
                changeInX = changeInX + (offset/7);
                if (changeInX >9) {
                    changeInX = 9;
                }
                if (changeInX < -9) {
                    changeInX = -9;
                }
                sound.setVolume(100);
                sound.play(); //Memainkan suara ("proton.mp3").
                ((Board) getWorld()).countScore(5); //Memanggil metode countScore(5) dari kelas Board untuk menambah skor.
            }   
            World world;
            world = getWorld();
            world.removeObject(block); //Menghapus blok dari dunia permainan.
        }
        else {
            ((Board) getWorld()).gameOver();
        }
    }

    /**
     * Menggerakkan bola ke samping dengan jarak tertentu.
     */
    public void move(int dist) //Metode untuk memindahkan posisi bola sejauh dist pada sumbu X.
    {
        setLocation (getX() + dist, getY());

    }

    /**
     * Meluncurkan bola dari paddle.
     */
    public void release() //Metode untuk melepaskan bola dari paddle.
    {
        changeInX = Greenfoot.getRandomNumber(11) - 5;; //Menetapkan perubahan kecepatan bola pada sumbu X dan Y secara acak.
        changeInY = -9;
        stuck = false; //Menetapkan stuck menjadi false sehingga bola tidak lagi terikat pada paddle.
    }
}