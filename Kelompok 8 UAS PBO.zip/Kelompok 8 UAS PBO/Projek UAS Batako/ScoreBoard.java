import greenfoot.*;

/**
 * Kelompok 8
 * Alfi Sukmanata - 2211102441168
 * Debby Fahrizal Rahman - 2211102441196
 * Muhammad Afif Aunur Rohman - 2211102441185
 * 
 * ScoreBoard digunakan untuk menampilkan skor di layar.
 */
public class ScoreBoard extends Actor
{
    public static final float FONT_SIZE = 48.0f; //Mendefinisikan ukuran font yang akan digunakan dalam skor papan.
    public static final int WIDTH = 400; //Mendefinisikan lebar papan skor.
    public static final int HEIGHT = 300; //Mendefinisikan tinggi papan skor.

    /**
     * Membuat scoreboard dengan skor uji coba untuk percobaan.
     */
    public ScoreBoard() //Konstruktor default yang digunakan untuk membuat papan skor dengan skor uji coba (dummy).
    {
        this(100);
    }

    /**
     * Membuat scoreboard untuk skor akhir.
     */
    public ScoreBoard(int score) //Konstruktor lain yang digunakan untuk membuat papan skor dengan skor akhir permainan yang sebenarnya.
    {
        makeImage("Game Over", "Score: ", score);
    }

    /**
     * Membuat gambar scoreboard.
     */
    private void makeImage(String title, String prefix, int score) //Metode ini bertanggung jawab untuk membuat gambar papan skor dengan judul, teks, dan skor yang diberikan. Gambar ini kemudian akan diatur sebagai gambar untuk objek ScoreBoard.
    {
        GreenfootImage image = new GreenfootImage(WIDTH, HEIGHT); //Membuat objek GreenfootImage dengan lebar dan tinggi yang telah ditentukan.

        image.setColor(new Color(0,127,171, 128)); //Mengatur warna dengan menggunakan objek Color dengan nilai RGBA (merah, hijau, biru, dan alpha) untuk transparansi. Dalam hal ini, digunakan warna biru dengan tingkat transparansi yang lebih rendah.
        image.fillRect(0, 0, WIDTH, HEIGHT); //Menggambar persegi panjang untuk latar belakang dengan ukuran yang telah ditentukan.
        image.setColor(new Color(0,127,171, 128)); //Mengatur warna lagi untuk bagian dalam persegi panjang agar sesuai dengan latar belakang.
        image.fillRect(5, 5, WIDTH-10, HEIGHT-10); //Menggambar persegi panjang yang lebih kecil di dalam untuk memberikan efek border.
        Font font = image.getFont(); //Mendapatkan font dari gambar.
        font = font.deriveFont(FONT_SIZE); //Mengubah ukuran font.
        image.setFont(font); //Mengatur font untuk gambar.
        image.setColor(Color.RED); //Mengatur warna untuk teks.
        image.drawString(title, 60, 100); //Menambahkan judul pada gambar pada koordinat (60, 100).
        image.drawString(prefix + score, 60, 200); //Menambahkan teks berisi skor pada gambar pada koordinat (60, 200).
        setImage(image); //Menetapkan gambar yang telah dibuat sebagai gambar untuk objek ScoreBoard.
    }
}
