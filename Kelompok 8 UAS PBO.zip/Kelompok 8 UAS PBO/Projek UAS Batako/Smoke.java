import greenfoot.*;

/**
 * Kelompok 8
 * Alfi Sukmanata - 2211102441168
 * Debby Fahrizal Rahman - 2211102441196
 * Muhammad Afif Aunur Rohman - 2211102441185
 * 
 * Gumpalan asap yang pergi menjauh lalu hilang
 */
public class Smoke  extends Actor
{
    private GreenfootImage image;   //Menyimpan gambar asli dari objek Smoke.
    private int fade;               //Menyimpan tingkat kecepatan fading (penyusutan dan pemudaran) asap.

    public Smoke() //Konstruktor kelas Smoke.
    {
        image = getImage(); //Mendapatkan gambar asli dari objek Smoke.
        fade = Greenfoot.getRandomNumber(4) + 1;  //Menginisialisasi variabel fade dengan nilai acak antara 1 hingga 4.
        if (fade > 3) {
            fade = 2;  //Mengubah nilai fade menjadi 2 jika nilai acak lebih dari 3, sehingga memiliki probabilitas dua kali lipat untuk mendapatkan nilai 2.
        }
    }

    /**
     * Di setiap langkah semakin kecil sampai menghilang
     */
    public void act() //Metode ini dipanggil setiap saat Greenfoot melakukan iterasi (frame) dalam permainan.
    {
        shrink(); //Memanggil metode shrink() untuk membuat asap menyusut.
    }    

    /**
     * Membuat gambar aktor ini menjadi semakin kecil. jika terlalu kecil
     * aktor dihapus
     */
    private void shrink() //Metode untuk membuat gambar objek Smoke menjadi sedikit lebih kecil. Jika gambar sudah sangat kecil, objek dihapus dari dunia.
    {
        if(getImage().getWidth() < 10) {
            getWorld().removeObject(this); //Jika lebar gambar sudah kurang dari 10 piksel, objek Smoke dihapus dari dunia.
        }
        else {
            GreenfootImage img = new GreenfootImage(image); //Membuat salinan gambar asli.
            img.scale( getImage().getWidth()-fade, getImage().getHeight()-fade ); //Menyusutkan gambar dengan mengurangi lebar dan tinggi sebesar nilai fade.
            img.setTransparency( getImage().getTransparency() - (fade*5) ); //Mengurangi tingkat transparansi gambar seiring waktu.
            setImage (img); //Mengatur gambar objek Smoke dengan gambar yang baru dibuat.
        }
    }
}
