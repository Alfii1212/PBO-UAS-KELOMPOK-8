import greenfoot.*; 

/**
 * Kelompok 8
 * Alfi Sukmanata - 2211102441168
 * Debby Fahrizal Rahman - 2211102441196
 * Muhammad Afif Aunur Rohman - 2211102441185
 * 
 * Counter class mengijinkan kita untuk menampilkan nilai numerical di layar.
 */
public class Counter extends Actor
{
    private static final Color transparent = new Color(0,0,0,0); //Variabel konstan yang menyimpan warna transparan.
    private GreenfootImage background; //Menyimpan gambar latar belakang.
    private int value; //Menyimpan nilai aktual dari counter.
    private int target; //Menyimpan nilai target untuk animasi.
    private String prefix; //Menyimpan teks prefix yang akan ditampilkan sebelum nilai counter.
    
    public Counter() //Konstruktor tanpa parameter yang memanggil konstruktor lainnya dengan parameter string kosong.
    {
        this(new String());
    }

    /**
     * Membuat counter baru, di inisiasi ke 0.
     */
    public Counter(String prefix) //Konstruktor dengan parameter yang menginisialisasi counter dengan nilai awal 0 dan nilai target 0, serta menyimpan teks prefix yang diberikan.
    {
        background = getImage();  //Mengambil gambar latar belakang dari objek 
        value = 0; //Inisialisasi nilai aktual ke 0.
        target = 0; //Inisialisasi nilai target ke 0.
        this.prefix = prefix; //Inisialisasi teks prefix.
        updateImage(); //Memanggil metode updateImage() untuk memperbarui tampilan gambar.
    }
    
    /**
     * MengAnimasikan tampilan untuk menghitung naik (atau turun) ke nilai target saat ini.
     */
    public void act() //Metode ini dipanggil setiap kali tombol "Act" atau "Run" ditekan dalam lingkungan permainan.
    {
        if (value < target) {
            value++;
            updateImage(); //Jika nilai aktual kurang dari nilai target, increment nilai aktual dan panggil updateImage().
        }
        else if (value > target) {
            value--;
            updateImage(); //Jika nilai aktual lebih dari nilai target, decrement nilai aktual dan panggil updateImage().
        }
    }

    /**
     * Menambahkan score baru ke nilai counter saat ini. ini akan menganimasikan 
     * counter pada frame yang berurutan hingga mencapai nilai baru.
     */
    public void add(int score) //Metode untuk menambahkan nilai ke nilai target.
    {
        target += score; //Menambahkan nilai parameter (score) ke nilai target.
    }

    /**
     * Mengembalikan nilai counter saat ini.
     */
    public int getValue() //Metode untuk mendapatkan nilai target saat ini.
    {
        return target; //Mengembalikan nilai target.
    }

    /**
     * Mengatur nilai counter baru.  ini tidak akan menganimasikan counter.
     */
    public void setValue(int newValue) //Metode untuk mengatur nilai target dan nilai aktual.
    {
        target = newValue; //Mengatur nilai target.
        value = newValue; //Mengatur nilai aktual.
        updateImage(); //Memanggil metode updateImage() untuk memperbarui tampilan gambar.
    }
    
    /**
     * Mengatur teks prefix yang seharusnya ditampilkan sebelumnya
     * nilai counter (e.g. "Score: ").
     */
    public void setPrefix(String prefix) //Metode untuk mengatur teks prefix.
    {
        this.prefix = prefix; //Mengatur teks prefix.
        updateImage(); //Memanggil metode updateImage() untuk memperbarui tampilan gambar.
    }

    /**
     * Memperbarui gambar di layar untuk menampilkan nilai terbaru
     */
    private void updateImage() //Metode untuk memperbarui gambar pada layar sehingga menampilkan nilai terbaru.
    {
        GreenfootImage image = new GreenfootImage(background); //Membuat salinan gambar latar belakang.
        GreenfootImage text = new GreenfootImage(prefix + value, 22, Color.WHITE, transparent); //Membuat gambar teks dengan nilai aktual dan teks prefix.
        
        if (text.getWidth() > image.getWidth() - 20) 
        {
            image.scale(text.getWidth() + 20, image.getHeight()); ////Jika lebar teks lebih besar dari lebar gambar dikurangi 20, skalakan gambar.
        }
        
        image.drawImage(text, (image.getWidth()-text.getWidth())/2, 
                        (image.getHeight()-text.getHeight())/2); //Menggambar teks di tengah gambar.
        setImage(image); //Mengatur gambar objek Counter dengan gambar yang baru dibuat.}
    }
}