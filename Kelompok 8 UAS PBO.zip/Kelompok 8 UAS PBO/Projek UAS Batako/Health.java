import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Kelompok 8
 * Alfi Sukmanata - 2211102441168
 * Debby Fahrizal Rahman - 2211102441196
 * Muhammad Afif Aunur Rohman - 2211102441185
 */
public class Health extends Actor
{
    /**
     * Act - do whatever the Health wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Health() //Konstruktor kelas Health.
    {
       //Konstruktor ini tidak memiliki implementasi yang jelas dalam kode yang diberikan.
    }
    
    
    public void remove() //Metode yang mencoba untuk menghapus objek dari dunia.
    {
        //getWorld().removeObject().get(0);
    }
}
