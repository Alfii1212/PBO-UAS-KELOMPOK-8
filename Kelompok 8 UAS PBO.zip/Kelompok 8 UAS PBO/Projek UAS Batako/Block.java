import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Kelompok 8
 * Alfi Sukmanata - 2211102441168
 * Debby Fahrizal Rahman - 2211102441196
 * Muhammad Afif Aunur Rohman - 2211102441185
 */
public class Block extends Actor
{
    private int speed = 2; //Variabel yang menyimpan nilai kecepatan pergerakan objek Block. Nilainya diatur awalnya ke 2.
    public void act() //Metode yang dipanggil setiap kali tombol "Act" atau "Run" ditekan dalam lingkungan permainan.
    {
        int length = getWorld().getWidth() + 9; //Variabel length diinisialisasi dengan lebar dunia permainan ditambah 9 piksel.
        if (speed > 0 && getX() == getWorld().getWidth() -1 ||
        (speed < 0 && getX() == 0)) //Pengecekan apakah objek Block berada di batas kanan atau kiri dunia permainan.
            speed = -speed; //Mengurangi kecepatan jika kondisi terpenuhi
        setLocation(getX() +speed, getY()); //Mengubah posisi objek Block berdasarkan kecepatan yang telah dihitung sebelumnya.    }
    }
}