import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Kelompok 8
 * Alfi Sukmanata - 2211102441168
 * Debby Fahrizal Rahman - 2211102441196
 * Muhammad Afif Aunur Rohman - 2211102441185
 */
public class Board extends World
{
    private Paddle paddle; //Objek Paddle yang akan digunakan dalam dunia.
    private int heart = 3; //Variabel untuk menyimpan jumlah nyawa atau health awal.
    private Counter scoreCounter; //Objek Counter untuk menghitung dan menampilkan skor.
    GreenfootSound music = new GreenfootSound("song.mp3"); //Objek suara untuk musik latar belakang.

    public Board() //Konstruktor untuk kelas Board.
    {    
        super(800, 600, 1);
        started(); //untuk memulai musik latar belakang.
        scoreCounter = new Counter("Score: "); //untuk skor dan menambahkannya ke dunia.
        addObject(scoreCounter, 80, 20); //mengatur posisi scoreCounter
        paddle = new Paddle(); //menambahkan paddle ke world.
        addObject ( paddle, getWidth() / 2, getHeight() - 40);
        prepare(); //ntuk menyiapkan blok-blok di world.
    }

    public void setHeart(int heart){ //Metode untuk mengatur jumlah nyawa.
        this.heart = heart; //Digunakan untuk mengupdate jumlah nyawa pada dunia.
    }

    public int getHeart(){ //Metode untuk mendapatkan jumlah nyawa.
        return heart; //Digunakan untuk mendapatkan nilai jumlah nyawa pada dunia.
    }

    public void ballOut() //Metode untuk memanggil metode newBall() pada objek Paddle.
    {
        paddle.newBall();
    }

    /**
     * Prepare the world for the start of the program. That is: create the initial
     * objects and add them to the world.
     */

    private void prepare() //Metode untuk menyiapkan blok-blok pada dunia.
    //Membuat dan menambahkan beberapa objek Block ke dunia pada posisi yang ditentukan.
    //Membuat dan menambahkan objek Health (nyawa) ke dunia.
    {
        Block block = new Block();
        addObject(block, 326, 199);
        Block block2 = new Block();
        addObject(block2, 534, 248);
        Block block3 = new Block();
        addObject(block3, 531, 135);
        Block block4 = new Block();
        addObject(block4, 262, 392);
        Block block5 = new Block();
        addObject(block5, 458, 253);
        Block block6 = new Block();
        addObject(block6, 476, 248);
        block6.setLocation(485, 319);
        block.setLocation(398, 83);
        block.setLocation(399, 52);
        block3.setLocation(447, 75);
        block5.setLocation(343, 74);
        block3.setLocation(451, 75);
        block5.setLocation(352, 75);
        block4.setLocation(302, 99);
        block2.setLocation(403, 100);
        block2.setLocation(399, 99);
        block6.setLocation(499, 99);
        block6.setLocation(498, 98);
        block6.setLocation(498, 99);
        Block block7 = new Block();
        addObject(block7, 259, 123);
        Block block8 = new Block();
        addObject(block8, 361, 123);
        block7.setLocation(258, 122);
        block8.setLocation(356, 122);
        Block block9 = new Block();
        addObject(block9, 459, 123);
        block9.setLocation(459, 123);
        block9.setLocation(455, 122);
        Block block10 = new Block();
        addObject(block10, 557, 120);
        block10.setLocation(554, 122);
        Block block11 = new Block();
        addObject(block11, 206, 147);
        Block block12 = new Block();
        addObject(block12, 319, 153);
        Block block13 = new Block();
        addObject(block13, 419, 153);
        block12.setLocation(313, 149);
        block11.setLocation(206, 146);
        block12.setLocation(305, 146);
        block13.setLocation(404, 146);
        Block block14 = new Block();
        addObject(block14, 506, 147);
        block14.setLocation(501, 147);
        block14.setLocation(504, 145);
        block14.setLocation(503, 146);
        Block block15 = new Block();
        addObject(block15, 604, 148);
        block15.setLocation(602, 146);
        Block block16 = new Block();
        addObject(block16, 168, 177);
        block16.setLocation(161, 169);
        Block block17 = new Block();
        addObject(block17, 265, 169);
        block17.setLocation(260, 169);
        Block block18 = new Block();
        addObject(block18, 363, 169);
        block18.setLocation(359, 169);
        Block block19 = new Block();
        addObject(block19, 462, 168);
        block19.setLocation(457, 169);
        Block block20 = new Block();
        addObject(block20, 558, 168);
        block20.setLocation(557, 169);
        Block block21 = new Block();
        addObject(block21, 195, 197);
        block21.setLocation(205, 191);
        Block block22 = new Block();
        addObject(block22, 310, 185);
        Block block23 = new Block();
        addObject(block23, 310, 185);
        block23.setLocation(413, 199);
        block22.setLocation(305, 191);
        block21.setLocation(206, 191);
        block23.setLocation(403, 191);
        Block block24 = new Block();
        addObject(block24, 506, 190);
        block24.setLocation(501, 191);
        Block block25 = new Block();
        addObject(block25, 656, 170);
        block25.setLocation(656, 169);
        Block block26 = new Block();
        addObject(block26, 606, 192);
        block26.setLocation(601, 191);
        Block block27 = new Block();
        addObject(block27, 256, 218);
        Block block28 = new Block();
        addObject(block28, 357, 217);
        block27.setLocation(257, 214);
        block28.setLocation(358, 214);
        block27.setLocation(259, 214);
        Block block29 = new Block();
        addObject(block29, 462, 213);
        Block block30 = new Block();
        addObject(block30, 548, 226);
        block29.setLocation(457, 214);
        block30.setLocation(555, 214);
        Block block31 = new Block();
        addObject(block31, 324, 240);
        block31.setLocation(303, 235);
        Block block32 = new Block();
        addObject(block32, 406, 234);
        block32.setLocation(403, 235);
        Block block33 = new Block();
        addObject(block33, 507, 236);
        block33.setLocation(507, 236);
        block32.setLocation(408, 236);
        block31.setLocation(308, 236);
        Block block34 = new Block();
        addObject(block34, 361, 259);
        Block block35 = new Block();
        addObject(block35, 455, 260);
        block34.setLocation(361, 257);
        block35.setLocation(460, 257);
        Block block36 = new Block();
        addObject(block36, 416, 282);
        block36.setLocation(414, 277);
        block.setLocation(402, 56);
        block36.setLocation(409, 277);
        block3.setLocation(453, 76);
        block5.setLocation(353, 78);
        block3.setLocation(455, 79);
        block5.setLocation(355, 79);
        block.setLocation(404, 60);
        block4.setLocation(302, 101);
        block2.setLocation(396, 101);
        block6.setLocation(494, 101);
        block5.setLocation(352, 81);
        block3.setLocation(455, 82);
        block5.setLocation(354, 82);
        block3.setLocation(451, 82);
        block7.setLocation(258, 127);
        block8.setLocation(356, 126);
        block9.setLocation(455, 126);
        block10.setLocation(556, 127);
        block9.setLocation(456, 126);
        block8.setLocation(358, 127);
        block9.setLocation(456, 127);
        block10.setLocation(555, 127);
        Health health = new Health();
        addObject(health, 716, 20);
        Health health2 = new Health();
        addObject(health2, 740, 20);
        Health health3 = new Health();
        addObject(health3, 764, 20);

    }

    public void gameOver() //Metode untuk menampilkan layar Game Over.
    {
        Greenfoot.delay(5);
        addObject(new ScoreBoard(scoreCounter.getValue()), getWidth()/2, getHeight()/2);
        Greenfoot.playSound("game-over.mp3"); //Memainkan suara Game Over.
        Greenfoot.stop(); //Menghentikan permainan dan menampilkan objek ScoreBoard dengan skor akhir.
    }

    public void countScore(int count) //Metode untuk menambahkan skor.
    {
        scoreCounter.add(count); //Memanggil metode add(count) pada objek scoreCounter untuk menambah skor.
    }

    public void started() //Metode untuk memulai musik latar belakang saat permainan dimulai.
    {  
        music.setVolume(35); //mengatur volume musik
        music.playLoop(); //membuat musik mengalami looping
    }  

    public void stopped() //Metode untuk menghentikan musik latar belakang saat permainan berakhir.
    {  
        music.stop(); //musik berhenti
    } 
}
