import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Kelompok 8
 * Alfi Sukmanata - 2211102441168
 * Debby Fahrizal Rahman - 2211102441196
 * Muhammad Afif Aunur Rohman - 2211102441185
 */
public class Paddle extends Actor
{
    private Ball myBall;  // digunakan sebelum bola di luncurkan
    /**
     * Saat paddle diciptakan, bola juga akan muncul.
     */
    public void addedToWorld(World world) //Metode ini dipanggil saat objek Paddle ditambahkan ke dalam dunia permainan.
    {
        newBall(); //Memanggil metode newBall() untuk membuat dan menempatkan bola di atas paddle.
    }
    
    /**
     * 
     */
    public void act() //Metode ini dipanggil setiap saat Greenfoot melakukan iterasi (frame) dalam permainan.
    {
        if( Greenfoot.isKeyDown("left"))
        {
            move(-9); //ika tombol panah kiri ("left") ditekan, maka pemain akan bergerak ke kiri (move(-9)).
        }
        if( Greenfoot.isKeyDown("right"))
        {
            move(9); //Jika tombol panah kanan ("right") ditekan, maka pemain akan bergerak ke kanan (move(9)).

        }
        if (haveBall() && Greenfoot.isKeyDown ("space")) {
            releaseBall(); //Jika paddle memiliki bola (haveBall() == true) dan tombol spasi ("space") ditekan, maka bola akan diluncurkan (releaseBall()).
        }
        
    }
    
    public void move(int dist) //Metode untuk memindahkan paddle sejauh dist satuan.
    {
        setLocation (getX() + dist, getY()); //Memindahkan lokasi paddle sejauh dist piksel secara horizontal.
        if (myBall != null) {
            myBall.move (dist); //bola yang terkait dengan paddle) tidak null, maka panggil myBall.move(dist) untuk memindahkan bola bersamaan dengan paddle.
        }
    }
    
    // newBall membuat bola di posisi paddle berada
    public void newBall() //Metode untuk membuat bola baru dan menempatkannya di atas paddle.
    {
        myBall = new Ball(); //Membuat objek bola baru dan menyimpannya dalam variabel myBall.
        getWorld().addObject (myBall, getX(), getY()-40); //Menambahkan objek bola ke dunia permainan di posisi yang relatif terhadap posisi paddle.
    }
    
    // Sets the haveBall flag to active.
    public boolean haveBall() //Metode yang mengembalikan true jika paddle memiliki bola (nilai myBall tidak null), dan false sebaliknya.
    {
        return myBall != null;
    }
        
    public void releaseBall() //Metode untuk melepaskan bola yang terkait dengan paddle.
    {
        myBall.release(); //Memanggil metode release() pada objek bola.
        myBall = null; //Menghapus referensi bola dari variabel myBall, sehingga tidak ada bola yang terkait dengan paddle setelah dilepaskan.
    }
}
